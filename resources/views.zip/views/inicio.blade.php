@extends('layouts.lgpage')
@section('content')
<div class="row">
    <div class="col-sm-2">
        <center><img src="https://i.imgur.com/eK7C3nt.jpg" alt="perfil grado" class="rounded-circle float-center"></center>
    </div>
    <div class="col-sm-10">Hola, mi nombre es <spam style="color:dodgerblue">Luis Gabriel Hernández Valderrama.</spam> Soy un amante del conocimiento, apasionado por <spam style="color:dodgerblue">la ciencia, las computadoras u ordenadores y la tecnología.</spam><br>Conoce mis páginas en el menu superior. <spam style="color:dodgerblue">Me desempeño en el area de sistemas</spam>, conoce mi portafolio en la página Web que figura debajo de este texto.</div>
</div>
@endsection
