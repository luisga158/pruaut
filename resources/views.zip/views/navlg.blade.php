<nav class="navbar navbar-expand-sm bg-dark navbar-dark"><a class="navbar-brand" href="{{ url('/inicio') }}">Menú</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse justify-content-center" id="collapsibleNavbar">
        <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link" href="{{ url('/inicio') }}">Inicio</a></li>
            <li class="nav-item"><a class="nav-link" href="{{ url('/pages') }}">Páginas</a></li>
            <li class="nav-item"><a class="nav-link" href="{{ url('/about') }}">Acerca de mi</a></li>
        </ul>
    </div>
</nav>